$(document).ready(function () {
    function afficher() {
        var letoken = document.cookie.split("=");
        letoken = letoken[1];
        $.ajax({
            method: "GET",
            url: "http://172.19.0.15/MVC/index.php?action=rdv&token=" + letoken,
        })
            .done(function (response) {
                console.log(response);
                response.forEach(function (rdv) {
                  $.ajax({
                    method: "GET",
                    url: "https://data.issy.com/api/records/1.0/search/?dataset=medecins-generalistes-et-infirmiers&refine.recordid=" + rdv.idMedecin,
                    dataType: "json",
                })
                    .done(function (data, textStatus, jqXHR) {
                        // Récupérer le nom et le prénom du médecin à partir des données de la deuxième requête AJAX
                        var medecin = data.records[0].fields;
                        var nomPrenom = medecin.prenom + " " + medecin.nom;
                        
                        // Ajouter le nom et le prénom du médecin à la ligne de tableau correspondant au rendez-vous
                        $('#rdv').append(
                            '<tr>' +
                            '<td>' + nomPrenom + '</td>' + // Afficher le nom et le prénom du médecin au lieu de l'ID
                            '<td>' + rdv.dateHeureRdv + '</td>' +
                            '<td><button class="supprimer" data-id="' + rdv.idRdv + '">Supprimer</button></td>' +
                            '<td><button class="modifier" data-id="' + rdv.idRdv + '">Modifier</button></td>' +
                            '</tr>'
                        );
                    });
            });
        });
    }
    afficher();
    $(document).on("click", ".supprimer", function() {
        var id = $(this).data('id');
        $.ajax({
          method: "DELETE",
          url: "http://172.19.0.15/MVC/index.php?action=rdv",
          data: JSON.stringify({id: id})
        })
        .done(function(response) {
          alert("Le rdv a été supprimé avec succès !");
          $('#rdv').empty();
          
          afficher();
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
          alert("Erreur lors de la suppression du rdv !");
          console.log(jqXHR); 
          console.log(textStatus); 
          console.log(errorThrown); 
        });
    });
    $(document).on("click", ".modifier", function() {
        var id = $(this).data('id');
       
        var dateHeure = $(this).closest('tr').find('td:eq(1)').text();
    
        $(this).closest('tr').find('td:eq(1)').html('<input type="text" id="date" value="' + dateHeure + '">');
        
        
        $(this).closest('tr').find('td:eq(3)').html('<button class="confirmer" data-id="' + id + '">Confirmer</button>'+'<button class="annuler">Annuler</button>');
  
      });

      
      $(document).on('click', '.modifier', function() {
        $('.modifier').not(this).prop('disabled', true);
      
        $(this).closest('tr').addClass('edit-mode');
      });
      
      
      $(document).on("click", ".annuler", function() {
        $('.modifier').prop('disabled', false);
        $('#rdv').empty();
        afficher();
      });
      
      
      $(document).on("click", ".confirmer", function() {
        $('.modifier').prop('disabled', false);
        var id = $(this).data('id');
        
        $.ajax({
          method: "PUT",
          url: "http://172.19.0.15/MVC/index.php?action=rdv",
          data: JSON.stringify({id : id, date: $('#date').val()})
        })
        .done(function(response) {
          alert("Le rdv a été modifié avec succès !");
          $('#rdv').empty(); 
      
          afficher();
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
          alert("La nouvelle date et heure sont déjà occupées pour ce médecin.");
          console.log(jqXHR); 
          console.log(textStatus); 
          console.log(errorThrown); 
        });  
      });

});
