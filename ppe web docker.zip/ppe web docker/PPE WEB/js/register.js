$("#enregistrer").click(function (event) {
    var prenom = $("input[name=prenom]").val();
    var nom = $("input[name=nom]").val();
    var adresse = $("input[name=adresse]").val();
    var codepostal = $("input[name=codepostal]").val();
    var ville = $("input[name=ville]").val();
    var telephone = $("input[name=telephone]").val();
    var login = $("input[name=login]").val();
    var password = $("input[name=password]").val();
    var password2 = $("input[name=password2]").val();

   
  


  
    if (prenom && nom && adresse && codepostal && ville && telephone && login && password && password2 && password === password2) {
        var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{12,}$");
  
        if (!strongRegex.test(password)) {
            alert("Le mot de passe doit contenir au moins une lettre majuscule, une lettre minuscule, un chiffre et avoir une longueur minimale de 12 caractères.");
            event.preventDefault();
            return;
        }

        var cpgex = new RegExp("^([0-9].{4,})$");
    
        if (!cpgex.test(codepostal)) {
          alert("Veuillez entrer uniquement des chiffres dans le champ de code postal.");
          return false;
        }

        var regex = new RegExp("^([0-9].{9,})$");
    
        if (!regex.test(telephone)) {
          alert("Veuillez entrer uniquement des chiffres dans le champ de téléphone.");
          return false;
        }

       

        $.ajax({
            method: "POST",
            url: "http://172.19.0.15/MVC/index.php?action=patient",
            data: JSON.stringify({
                nom: nom,
                prenom: prenom,
                rue: adresse,
                cp: codepostal,
                ville: ville,
                tel: telephone,
                login: login,
                mdp: password
            })
        })
        .done(function (data, textStatus, jqXHR) {
            alert("Connecté avec succès !");

            var token = data.token;
            document.cookie = "token=" + token;

            window.location.replace("/PPE WEB/index.html");

            console.log(data);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Erreur !");
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        });
    }
    else
    {
        alert("Veuillez remplir tous les champs et vérifier que les mots de passe sont identiques.");
    }
    
  
    event.preventDefault();
  
  });
  